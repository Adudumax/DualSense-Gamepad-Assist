# DualSense Gamepad Assist 0.6.2 English

Author: `Adudumax`

DualSense Gamepad Assist is an Assetto Corsa CSP `Gamepad FX` script with controller steering assist, automatic clutch, optional automatic shifting, CSP native haptics, and adaptive triggers. Version `0.6.2` only reorganizes internal naming, text, and release packaging. It does not change the verified vibration feel.

The project does not read gyroscope data or modify gyroscope steering.

## Features

- Dark translucent UI with a compact overview and an independent, resizable advanced settings window.
- CSP DualSense native haptics for engine texture, bodywork and curb detail, tire skid, gear shifts, and collisions.
- A `0.5.1` compatibility grip layer using `vibrationLeft / vibrationRight` alongside CSP native haptics.
- Adaptive triggers: L2 braking resistance and ABS cues; R2 throttle resistance, wheelspin, limiter pulses, and shift rebound.
- Three built-in feedback presets plus save and load buttons for a custom preset.
- Controller steering assist, automatic clutch, optional automatic shifting, calibration, graphs, gamma, and deadzone controls.

## Installation

1. Install Content Manager and CSP `0.2.0` or newer.
2. Open the `DualSense Gamepad Assist` folder from the archive.
3. Copy its `apps` and `extension` folders into the Assetto Corsa root folder, `assettocorsa`.
4. In Content Manager, open `Settings -> Custom Shaders Patch -> Gamepad FX`.
5. Enable Gamepad FX and select `DualSense Gamepad Assist`.
6. Confirm that the AC input method is set to `Gamepad`.
7. Enter a session and open `DualSense Gamepad Assist` from the in-game app sidebar.

A USB connection is recommended. If dedicated feedback is missing, disable Steam Input for Assetto Corsa and enter the session again.

## UI Pages

- `Overview`: feedback presets, custom preset actions, grip vibration strength, core switches, automatic clutch, and shifting mode.
- `Advanced settings`: an independent, movable, resizable window.
- `Steering`: assist, calibration, presets, detailed steering controls, gamma, and deadzone.
- `Feedback`: engine, curbs, skid, shifts, collisions, compatibility grip layer, L2, and R2 essentials.
- `Diagnostics`: native-layer isolation tests, live telemetry, full haptics controls, and trigger details.

## Notes

The CSP Lua SDK exposes gain, pitch, and normalization controls for semantic DualSense haptic layers. It does not expose direct left and right native-actuator writes. Left and right curb cues use `Bodywork` pitch separation for clarity, which is not the same as independent actuator control.

The steering-assist implementation references AC Advanced Gamepad Assist. Third-party attribution and the MIT License copy are provided in `THIRD_PARTY_NOTICES.md` and `licenses/UPSTREAM-MIT-LICENSE.txt`.
