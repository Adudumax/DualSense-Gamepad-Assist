# DualSense Gamepad Assist 0.6.2 中文版

作者：`Adudumax`

这是一个面向 Assetto Corsa CSP `Gamepad FX` 的 DualSense 脚本，提供游戏手柄转向辅助、自动离合、自动换挡、CSP 原生触觉层和自适应扳机。`0.6.2` 只整理内部命名、文案和发布结构，不改变已经验证满意的震动反馈。

本项目不会读取陀螺仪，也不会修改陀螺仪转向。

## 特点

- 深色半透明 UI：首页直接显示总览，并从首页打开独立、可自由调整大小的高级设置窗口。
- DualSense 原生触觉：保留 `Bodywork` 路肩、`Skid` 侧滑、`Engine`、换挡和碰撞反馈。
- `0.5.1` 兼容握把补充层：保留 `vibrationLeft / vibrationRight` 输出，与 CSP 原生触觉并行工作。
- 自适应扳机：保留 L2 刹车阻力、ABS 提示，以及 R2 油门阻力、驱动轮空转、高转红线提示和换挡回弹。
- 可保存和载入自定义反馈预设，并提供 `平衡推荐`、`细腻赛道`、`强烈反馈` 三组预设。
- 转向辅助、自动离合、自动换挡、校准、图表、Gamma 和死区调节。

## 安装

1. 安装 Content Manager 与 CSP `0.2.0` 或更高版本。
2. 打开压缩包中的 `DualSense Gamepad Assist` 文件夹。
3. 把其中的 `apps` 和 `extension` 文件夹复制到 AC 游戏根目录 `assettocorsa`。
4. 在 Content Manager 中打开 `设置 -> Custom Shaders Patch -> Gamepad FX`。
5. 勾选启用，并选择 `DualSense Gamepad Assist`。
6. 在 AC 控制设置中确认输入方式为 `Gamepad`。
7. 进入赛道后，从右侧应用栏打开 `DualSense Gamepad Assist`。

推荐使用 USB 连接 DualSense。若没有专属反馈，请在 Steam 的 Assetto Corsa 控制器属性中关闭 Steam Input，再重新进入游戏测试。

## UI 页面

- `首页总览`：反馈预设、自定义预设、握把震动总强度、核心开关、自动离合和换挡模式。
- `高级设置`：独立窗口，可自由移动和调整大小。
- `转向`：辅助、校准、预设、完整转向参数、Gamma 和死区。
- `反馈`：发动机、路肩、侧滑、换挡、碰撞、兼容握把补充层、L2 与 R2 常用参数。
- `诊断`：原生层隔离测试、实时遥测、完整原生触觉参数和扳机细项。

## 说明

CSP Lua SDK 只允许调整 DualSense 原生触觉语义层的增益、音调和归一化参数，没有暴露直接写入左右原生执行器的接口。左右路肩通过 `Bodywork` 音调变化增强辨识度，不等同于真正独立控制左右执行器。

转向辅助部分参考了 AC Advanced Gamepad Assist。第三方归属与 MIT License 说明位于 `THIRD_PARTY_NOTICES.md` 与 `licenses/UPSTREAM-MIT-LICENSE.txt`。
